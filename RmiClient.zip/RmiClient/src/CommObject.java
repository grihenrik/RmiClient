
import java.io.Serializable;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Henrik18001
 */
public class CommObject implements Serializable{
    private String cObject;
    public String CommObject(){
        this.cObject="{}"; 
        return this.cObject;
    }
    
    public String CommObject(String first, String second){
        this.cObject="{\""+first+"\": \""+second+"\"}";
        return this.cObject;
    }
    
    /**
     * @return the cObject
     */
    public String getcObject() {
        return cObject;
    }

    /**
     * @param cObject the cObject to set
     */
    public void setcObject(String cObject) {
        this.cObject = cObject;
    }
}
